// config.js

// const baseURL = 'http://localhost:5000';
const baseURL = "https://lostandfoundbackend-y9qs.onrender.com";
const config = {
  baseURL,
};

export default config;
